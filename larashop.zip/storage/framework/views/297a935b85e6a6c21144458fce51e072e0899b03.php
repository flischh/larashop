<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="card card-default">
					<div class="card-header card-header-border-bottom">
						<h2>Revenue Report</h2>
					</div>
					<div class="card-body">
						<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo $__env->make('admin.reports.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<table class="table table-bordered table-striped">
							<thead>
								<th>Date</th>
								<th>Orders</th>
								<th>Gross Revenue</th>
								<th>Taxes</th>
								<th>Shipping</th>
								<th>Net Revenue</th>
							</thead>
							<tbody>
								<?php
									$totalOrders = 0;
									$totalGrossRevenue = 0;
									$totalTaxesAmount = 0;
									$totalShippingAmount = 0;
									$totalNetRevenue = 0;
								?>
								<?php $__empty_1 = true; $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>    
										<td><?php echo e(\General::datetimeFormat($revenue->date, 'd M Y')); ?></td>
										<td>
											<a href="<?php echo e(url('admin/orders?start='. $revenue->date .'&end='. $revenue->date . '&status=completed')); ?>"><?php echo e($revenue->num_of_orders); ?></a>
										</td>
										<td><?php echo e(\General::priceFormat($revenue->gross_revenue)); ?></td>
										<td><?php echo e(\General::priceFormat($revenue->taxes_amount)); ?></td>
										<td><?php echo e(\General::priceFormat($revenue->shipping_amount)); ?></td>
										<td><?php echo e(\General::priceFormat($revenue->net_revenue)); ?></td>
									</tr>

									<?php
										$totalOrders += $revenue->num_of_orders;
										$totalGrossRevenue += $revenue->gross_revenue;
										$totalTaxesAmount += $revenue->taxes_amount;
										$totalShippingAmount += $revenue->shipping_amount;
										$totalNetRevenue += $revenue->net_revenue;
									?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<tr>
										<td colspan="6">No records found</td>
									</tr>
								<?php endif; ?>
								
								<?php if($revenues): ?>
									<tr>
										<td>Total</td>
										<td><strong><?php echo e($totalOrders); ?></strong></td>
										<td><strong><?php echo e(\General::priceFormat($totalGrossRevenue)); ?></strong></td>
										<td><strong><?php echo e(\General::priceFormat($totalTaxesAmount)); ?></strong></td>
										<td><strong><?php echo e(\General::priceFormat($totalShippingAmount)); ?></strong></td>
										<td><strong><?php echo e(\General::priceFormat($totalNetRevenue)); ?></strong></td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/reports/revenue.blade.php ENDPATH**/ ?>