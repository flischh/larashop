<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Trashed Orders</h2>
                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-bordered table-stripped">
                            <thead>
                                <th>Order ID</th>
                                <th>Grand Total</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>    
                                        <td>
                                            <?php echo e($order->code); ?><br>
                                            <span style="font-size: 12px; font-weight: normal"> <?php echo e(\General::datetimeFormat($order->order_date)); ?></span>
                                        </td>
                                        <td><?php echo e(\General::priceFormat($order->grand_total)); ?></td>
                                        <td>
                                            <?php echo e($order->customer_full_name); ?><br>
                                            <span style="font-size: 12px; font-weight: normal"> <?php echo e($order->customer_email); ?></span>
                                        </td>
                                        <td><?php echo e($order->status); ?></td>
                                        <td><?php echo e($order->payment_status); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_orders')): ?>
                                                <a href="<?php echo e(url('admin/orders/'. $order->id)); ?>" class="btn btn-info btn-sm">show</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">No records found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/orders/trashed.blade.php ENDPATH**/ ?>