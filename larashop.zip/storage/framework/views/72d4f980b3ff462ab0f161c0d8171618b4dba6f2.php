<div class="card card-default">
    <div class="card-header card-header-border-bottom">
            <h2>Add Option</h2>
    </div>
    <div class="card-body">
        <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(!empty($attributeOption)): ?>
            <?php echo Form::model($attributeOption, ['url' => ['admin/attributes/options', $attributeOption->id], 'method' => 'PUT']); ?>

            <?php echo Form::hidden('id'); ?>

        <?php else: ?>
            <?php echo Form::open(['url' => ['admin/attributes/options', $attribute->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <?php endif; ?>
        <?php echo Form::hidden('attribute_id', $attribute->id); ?>

        <div class="form-group">
            <?php echo Form::label('name', 'Name'); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-footer pt-5 border-top">
            <button type="submit" class="btn btn-primary btn-default">Save</button>
            <a href="<?php echo e(url('admin/attributes/')); ?>" class="btn btn-secondary btn-default">Back</a>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div> <?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/attributes/option_form.blade.php ENDPATH**/ ?>