<?php $__env->startComponent('mail::message'); ?>
# Yeay, your order has been shipped!
We shipped your order at <strong><?php echo e(\General::datetimeFormat($order->shipment->shipped_at)); ?></strong> and here is your tracking number: <strong><?php echo e($order->shipment->track_number); ?></strong>
<br>
<br/>
Your order details are shown below for your reference:
## Order #<?php echo e($order->code); ?> (<?php echo e(\General::datetimeFormat($order->order_date)); ?>)

<?php $__env->startComponent('mail::table'); ?>
| Product       | Quantity      | Price  |
| ------------- |:-------------:| --------:|
<?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo e($item->name); ?>      |  <?php echo e($item->qty); ?>      | <?php echo e(\General::priceFormat($item->sub_total)); ?>      |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
| &nbsp;         | <strong>Sub total</strong> | <?php echo e(\General::priceFormat($order->base_total_price)); ?> |
| &nbsp;         | Tax (10%)     | <?php echo e(\General::priceFormat($order->tax_amount)); ?> |
| &nbsp;         | Shipping cost | <?php echo e(\General::priceFormat($order->shipping_cost)); ?> |
| &nbsp;         | <strong>Total</strong> | <strong><?php echo e(\General::priceFormat($order->grand_total)); ?></strong>|
<?php echo $__env->renderComponent(); ?>

## Billing Details:
<strong><?php echo e($order->customer_first_name); ?> <?php echo e($order->customer_last_name); ?></strong>
<br> <?php echo e($order->customer_address1); ?>

<br> <?php echo e($order->customer_address2); ?>

<br> Email: <?php echo e($order->customer_email); ?>

<br> Phone: <?php echo e($order->customer_phone); ?>

<br> Postcode: <?php echo e($order->customer_postcode); ?>


## Shipment Address (shipped by: <?php echo e($order->shipping_service_name); ?>):
<strong><?php echo e($order->shipment->first_name); ?> <?php echo e($order->shipment->last_name); ?></strong>
<br> <?php echo e($order->shipment->address1); ?>

<br> <?php echo e($order->shipment->address2); ?>

<br> Email: <?php echo e($order->shipment->email); ?>

<br> Phone: <?php echo e($order->shipment->phone); ?>

<br> Postcode: <?php echo e($order->shipment->postcode); ?>


<?php $__env->startComponent('mail::button', ['url' => url('orders/received/'. $order->id)]); ?>
Show order detail
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\larashop\resources\views/emails/orders/shipped.blade.php ENDPATH**/ ?>