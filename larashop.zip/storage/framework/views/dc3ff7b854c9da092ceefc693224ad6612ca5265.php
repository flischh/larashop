<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="row">
		<div class="col-lg-6">
			<div class="card card-default">
				<div class="card-header card-header-border-bottom">
					<h2>Order Shipment #<?php echo e($shipment->order->code); ?></h2>
				</div>
				<div class="card-body">
					<?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php echo Form::model($shipment, ['url' => ['admin/shipments', $shipment->id], 'method' => 'PUT']); ?>

					<?php echo Form::hidden('id'); ?>

					<div class="form-group row">
						<div class="col-md-6">
							<?php echo Form::label('first_name', 'First name'); ?>

							<?php echo Form::text('first_name', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
						<div class="col-md-6">
							<?php echo Form::label('last_name', 'Last name'); ?>

							<?php echo Form::text('last_name', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
					</div>
					<div class="form-group">
						<?php echo Form::label('company', 'Company'); ?>

						<?php echo Form::text('company', null, ['class' => 'form-control', 'readonly' => true]); ?>

					</div>
					<div class="form-group">
						<?php echo Form::label('address1', 'Home number and street name'); ?>

						<?php echo Form::text('address1', null, ['class' => 'form-control', 'readonly' => true]); ?>

					</div>
					<div class="form-group">
						<?php echo Form::label('address2', 'Apartment, suite, unit etc. (optional)'); ?>

						<?php echo Form::text('address2', null, ['class' => 'form-control', 'readonly' => true]); ?>

					</div>
					<div class="form-group">
						<?php echo Form::label('province_id', 'Province'); ?>

						<?php echo Form::select('province_id', $provinces, $shipment->province_id, ['id' => 'province-id', 'class' => 'form-control', 'disabled' => true]); ?>

					</div>
					<div class="form-group row">
						<div class="col-md-6">
							<?php echo Form::label('city_id', 'City'); ?>

							<?php echo Form::select('city_id', $cities, $shipment->city_id, ['id' => 'city-id', 'class' => 'form-control', 'disabled' => true]); ?>

						</div>
						<div class="col-md-6">
							<?php echo Form::label('postcode', 'Postcode / zip'); ?>

							<?php echo Form::text('postcode', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
					</div>
					<div class="form-group row">
						<div class="col-md-6">
							<?php echo Form::label('phone', 'Phone'); ?>

							<?php echo Form::text('phone', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
						<div class="col-md-6">
							<?php echo Form::label('email', 'Email'); ?>

							<?php echo Form::text('email', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
					</div>
					<div class="form-group row">
						<div class="col-md-6">
							<?php echo Form::label('total_qty', 'Quantity'); ?>

							<?php echo Form::text('total_qty', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
						<div class="col-md-6">
							<?php echo Form::label('total_weight', 'Total Weight (gram)'); ?>

							<?php echo Form::text('total_weight', null, ['class' => 'form-control', 'readonly' => true]); ?>

						</div>
					</div>
					<div class="form-group">
						<?php echo Form::label('track_number', 'Track Number'); ?>

						<?php echo Form::text('track_number', null, ['class' => 'form-control']); ?>

					</div>
					<div class="form-footer pt-5 border-top">
						<button type="submit" class="btn btn-primary btn-default">Save</button>
						<a href="<?php echo e(url('admin/orders/'. $shipment->order->id)); ?>" class="btn btn-secondary btn-default">Back</a>
					</div>
					<?php echo Form::close(); ?>

				</div>
			</div>  
		</div>
		<div class="col-lg-6">
			<div class="card card-default">
				<div class="card-header card-header-border-bottom">
					<h2>Detail Order</h2>
				</div>
				<div class="card-body">
					<div class="row">
						<div class="col-xl-6 col-lg-6">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Billing Address</p>
							<address>
								<?php echo e($shipment->order->customer_first_name); ?> <?php echo e($shipment->order->customer_last_name); ?>

								<br> <?php echo e($shipment->order->customer_address1); ?>

								<br> <?php echo e($shipment->order->customer_address2); ?>

								<br> Email: <?php echo e($shipment->order->customer_email); ?>

								<br> Phone: <?php echo e($shipment->order->customer_phone); ?>

								<br> Postcode: <?php echo e($shipment->order->customer_postcode); ?>

							</address>
						</div>
						<div class="col-xl-6 col-lg-6">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Details</p>
							<address>
								ID: <span class="text-dark">#<?php echo e($shipment->order->code); ?></span>
								<br> <?php echo e(\General::datetimeFormat($shipment->order->order_date)); ?>

								<br> Status: <?php echo e($shipment->order->status); ?>

								<br> Payment Status: <?php echo e($shipment->order->payment_status); ?>

								<br> Shipped by: <?php echo e($shipment->order->shipping_service_name); ?>

							</address>
						</div>
					</div>
					<table class="table mt-3 table-striped table-responsive table-responsive-large" style="width:100%">
						<thead>
							<tr>
								<th>#</th>
								<th>Item</th>
								<th>Qty</th>
								<th>Total</th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $shipment->order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($item->sku); ?></td>
									<td><?php echo e($item->name); ?></td>
									<td><?php echo e($item->qty); ?></td>
									<td><?php echo e(\General::priceFormat($item->sub_total)); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="6">Order item not found!</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
					<div class="row justify-content-end">
						<div class="col-lg-5 col-xl-6 col-xl-3 ml-sm-auto">
							<ul class="list-unstyled mt-4">
								<li class="mid pb-3 text-dark">Subtotal
									<span class="d-inline-block float-right text-default"><?php echo e(\General::priceFormat($shipment->order->base_total_price)); ?></span>
								</li>
								<li class="mid pb-3 text-dark">Tax(10%)
									<span class="d-inline-block float-right text-default"><?php echo e(\General::priceFormat($shipment->order->tax_amount)); ?></span>
								</li>
								<li class="mid pb-3 text-dark">Shipping Cost
									<span class="d-inline-block float-right text-default"><?php echo e(\General::priceFormat($shipment->order->shipping_cost)); ?></span>
								</li>
								<li class="pb-3 text-dark">Total
									<span class="d-inline-block float-right"><?php echo e(\General::priceFormat($shipment->order->grand_total)); ?></span>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/shipments/edit.blade.php ENDPATH**/ ?>