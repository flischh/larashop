<?php $__env->startSection('content'); ?>
	
<?php
	$formTitle = !empty($slide) ? 'Update' : 'New'    
?>

<div class="content">
	<div class="row">
		<div class="col-lg-6">
			<div class="card card-default">
				<div class="card-header card-header-border-bottom">
						<h2><?php echo e($formTitle); ?> Slide</h2>
				</div>
				<div class="card-body">
					<?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php if(!empty($slide)): ?>
						<?php echo Form::model($slide, ['url' => ['admin/slides', $slide->id], 'method' => 'PUT', 'enctype' => 'multipart/form-data']); ?>

						<?php echo Form::hidden('id'); ?>

					<?php else: ?>
						<?php echo Form::open(['url' => 'admin/slides', 'enctype' => 'multipart/form-data']); ?>

					<?php endif; ?>
						<div class="form-group">
							<?php echo Form::label('title', 'Title'); ?>

							<?php echo Form::text('title', null, ['class' => 'form-control']); ?>

						</div>
						<div class="form-group">
							<?php echo Form::label('url', 'URL'); ?>

							<?php echo Form::text('url', null, ['class' => 'form-control']); ?>

						</div>
					<?php if(empty($slide)): ?>
						<div class="form-group">
							<?php echo Form::label('image', 'Slide Image (1920x643 pixel)'); ?>

							<?php echo Form::file('image', ['class' => 'form-control-file', 'placeholder' => 'product image']); ?>

						</div>
					<?php endif; ?>
						<div class="form-group">
							<?php echo Form::label('body', 'Body'); ?>

							<?php echo Form::textarea('body', null, ['class' => 'form-control', 'rows' => 3]); ?>

						</div>
						<div class="form-group">
							<?php echo Form::label('status', 'Status'); ?>

							<?php echo Form::select('status', $statuses , null, ['class' => 'form-control', 'placeholder' => '-- Set Status --']); ?>

						</div>
						<div class="form-footer pt-5 border-top">
							<button type="submit" class="btn btn-primary btn-default">Save</button>
							<a href="<?php echo e(url('admin/slides')); ?>" class="btn btn-secondary btn-default">Back</a>
						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>  
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/slides/form.blade.php ENDPATH**/ ?>