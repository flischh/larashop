<div class="card">
    <div class="card-header" id="heading-<?php echo e(isset($title) ? Str::slug($title) : 'permission-heading'); ?>">
        <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-<?php echo e(isset($title) ? Str::slug($title) : 'permission-heading'); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e(isset($title) ? Str::slug($title) : 'permission-heading'); ?>">
            <?php echo e($title); ?>

        </a>
    </div>

    <div id="collapse-<?php echo e(isset($title) ? Str::slug($title) : 'permission-heading'); ?>" class="collapse" aria-labelledby="heading-<?php echo e(isset($title) ? Str::slug($title) : 'permission-heading'); ?>" data-parent="#accordion-role-permission" style="">
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $per_found = null;
                        if( isset($role) ) {
                            $per_found = $role->hasPermissionTo($perm->name);
                        }
                        if( isset($user)) {
                            $per_found = $user->hasDirectPermission($perm->name);
                        }
                    ?>

                    <div class="col-md-3">
                        <div class="checkbox">
                            <label class="<?php echo e(Str::contains($perm->name, 'delete') ? 'text-danger' : ''); ?>">
                                <?php echo Form::checkbox("permissions[]", $perm->name, $per_found, isset($options) ? $options : []); ?> <?php echo e($perm->name); ?>

                            </label>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_roles')): ?>
            <div class="card-footer">
                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/roles/_permissions.blade.php ENDPATH**/ ?>