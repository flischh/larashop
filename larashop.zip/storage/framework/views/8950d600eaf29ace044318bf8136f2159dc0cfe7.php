<?php $__env->startSection('content'); ?>
    
<?php
    $formTitle = !empty($product) ? 'Update' : 'New'    
?>

<div class="content">
    <div class="row">
        <div class="col-lg-3">
            <?php echo $__env->make('admin.products.product_menus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-9">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2><?php echo e($formTitle); ?> Product</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(!empty($product)): ?>
                        <?php echo Form::model($product, ['url' => ['admin/products', $product->id], 'method' => 'PUT']); ?>

                        <?php echo Form::hidden('id'); ?>

                        <?php echo Form::hidden('type'); ?>

                    <?php else: ?>
                        <?php echo Form::open(['url' => 'admin/products']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('type', 'Type'); ?>

                            <?php echo Form::select('type', $types , !empty($product) ? $product->type : null, ['class' => 'form-control product-type', 'placeholder' => '-- Choose Product Type --', 'disabled' => !empty($product)]); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('sku', 'SKU'); ?>

                            <?php echo Form::text('sku', null, ['class' => 'form-control', 'placeholder' => 'sku']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('name', 'Name'); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'name']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('category_ids', 'Category'); ?>

                            <?php echo General::selectMultiLevel('category_ids[]', $categories, ['class' => 'form-control', 'multiple' => true, 'selected' => !empty(old('category_ids')) ? old('category_ids') : $categoryIDs, 'placeholder' => '-- Choose Category --']); ?>

                        </div>
                        <div class="configurable-attributes">
                            <?php if(!empty($configurableAttributes) && empty($product)): ?>
                                <p class="text-primary mt-4">Configurable Attributes</p>
                                <hr/>
                                <?php $__currentLoopData = $configurableAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <?php echo Form::label($attribute->code, $attribute->name); ?>

                                        <?php echo Form::select($attribute->code. '[]', $attribute->attributeOptions->pluck('name','id'), null, ['class' => 'form-control', 'multiple' => true]); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <?php if($product): ?>
                            <?php if($product->type == 'configurable'): ?>
                                <?php echo $__env->make('admin.products.configurable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('admin.products.simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                            
                            <?php endif; ?>

                            <div class="form-group">
                                <?php echo Form::label('short_description', 'Short Description'); ?>

                                <?php echo Form::textarea('short_description', null, ['class' => 'form-control', 'placeholder' => 'short description']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('description', 'Description'); ?>

                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'description']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('status', 'Status'); ?>

                                <?php echo Form::select('status', $statuses , null, ['class' => 'form-control', 'placeholder' => '-- Set Status --']); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-footer pt-5 border-top">
                            <button type="submit" class="btn btn-primary btn-default">Save</button>
                            <a href="<?php echo e(url('admin/products')); ?>" class="btn btn-secondary btn-default">Back</a>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>  
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/products/form.blade.php ENDPATH**/ ?>