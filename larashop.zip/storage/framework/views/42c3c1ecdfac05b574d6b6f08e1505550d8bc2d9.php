<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('price', 'Price'); ?>

            <?php echo Form::text('price', null, ['class' => 'form-control', 'placeholder' => 'price']); ?>

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('weight', 'Weight'); ?>

            <?php echo Form::text('weight', null, ['class' => 'form-control', 'placeholder' => 'weight']); ?>

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('qty', 'Qty Inventory'); ?>

            <?php echo Form::text('qty', null, ['class' => 'form-control', 'placeholder' => 'qty']); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('length', 'Length'); ?>

            <?php echo Form::text('length', null, ['class' => 'form-control', 'placeholder' => 'length']); ?>

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('width', 'Width'); ?>

            <?php echo Form::text('width', null, ['class' => 'form-control', 'placeholder' => 'width']); ?>

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('height', 'Height'); ?>

            <?php echo Form::text('height', null, ['class' => 'form-control', 'placeholder' => 'height']); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\larashop\resources\views/admin/products/simple.blade.php ENDPATH**/ ?>