<div class="shop-sidebar mr-50">
    <form method="GET" action="<?php echo e(url('products')); ?>">
        <div class="sidebar-widget mb-40">
            <h3 class="sidebar-title">Filter by Price</h3>
            <div class="price_filter">
                <div id="slider-range"></div>
                <div class="price_slider_amount">
                    <div class="label-input">
                        <label>price : </label>
                        <input type="text" id="amount" name="price"  placeholder="Add Your Price" style="width:170px" />
                        <input type="hidden" id="productMinPrice" value="<?php echo e($minPrice); ?>"/>
                        <input type="hidden" id="productMaxPrice" value="<?php echo e($maxPrice); ?>"/>
                    </div>
                    <button type="submit">Filter</button> 
                </div>
            </div>
        </div>
    </form>

    <?php if($categories): ?>
        <div class="sidebar-widget mb-45">
            <h3 class="sidebar-title">Categories</h3>
            <div class="sidebar-categories">
                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('products?category='. $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if($colors): ?>
        <div class="sidebar-widget sidebar-overflow mb-45">
            <h3 class="sidebar-title">color</h3>
            <div class="sidebar-categories">
                <ul>
                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('products?option='. $color->id)); ?>"><?php echo e($color->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>

    <?php if($sizes): ?>
        <div class="sidebar-widget mb-40">
            <h3 class="sidebar-title">size</h3>
            <div class="product-size">
                <ul>
                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('products?option='. $size->id)); ?>"><?php echo e($size->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\larashop\resources\views/themes/ezone/products/sidebar.blade.php ENDPATH**/ ?>