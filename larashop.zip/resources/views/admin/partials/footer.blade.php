        <footer class="footer mt-auto">
            <div class="copyright bg-white">
              <p>Copyright © Merry Boutique 2020 . All Right Reserved.</p>
            </div>
            <script>
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("copy-year").innerHTML = year;
            </script>
          </footer>