@extends('themes.ezone.layout')

@section('content')
    @include('themes.ezone.partials.slider')
    @include('themes.ezone.partials.popular_products')
@endsection